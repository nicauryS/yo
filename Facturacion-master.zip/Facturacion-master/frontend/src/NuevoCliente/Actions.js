export const getDefaultState = Symbol('getDefaultState');
export const updateInput = Symbol('updateInput');
export const guardar = Symbol('guardar');
export const cerrar = Symbol('cerrar');
export const editar = Symbol('editar');
export const setServerError = Symbol('setServerError');
