import React, { Component } from 'react';
import MainNavigationView from './MainNavigationView';

class App extends Component {
  render() {
    return <MainNavigationView />;
  }
}

export default App;
