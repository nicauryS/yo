export const getDefaultState = Symbol('getDefaultState');
export const updateFormaPago = Symbol('updateFormaPago');
export const updateValor = Symbol('updateValor');
export const agregarPago = Symbol('agregarPago');
export const removerPago = Symbol('removerPago');
export const guardarPagos = Symbol('guardarPagos');
