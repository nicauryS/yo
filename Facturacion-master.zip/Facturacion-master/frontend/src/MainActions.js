export const getDefaultState = Symbol('getDefaultState');
export const mostrarInputDialog = Symbol('mostrarInputDialog');
export const cerrarInputDialog = Symbol('cerrarInputDialog');
export const toggleDrawerMenu = Symbol('toggleDrawerMenu');
export const mostrarSnackbar = Symbol('mostrarSnackbar');
export const cerrarSnackbar = Symbol('cerrarSnackbar');
